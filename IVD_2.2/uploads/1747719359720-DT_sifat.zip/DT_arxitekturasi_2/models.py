from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)       # Talabaning yagona identifikatori (primary key)
    name = db.Column(db.String(100), nullable=False)    # Talabaning ismi - bo'sh bo'lishi mumkin emas
    grades = db.relationship('Grade', backref='student', lazy=True)   # Talabaning baholari bilan bog'lanish

class Grade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    subject = db.Column(db.String(100), nullable=False)  # Fan nomi - bo'sh bo'lishi mumkin emas
    score = db.Column(db.Integer, nullable=False)  # Ball yoki baho - bo'sh bo'lishi mumkin emas
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    # Bu baho qaysi talabaga tegishli ekanligini ko'rsatadi