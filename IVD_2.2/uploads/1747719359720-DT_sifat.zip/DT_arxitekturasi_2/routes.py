from flask import Flask, render_template, request, redirect, url_for
from models import db, Student, Grade

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///grades.db'
db.init_app(app)  # Flask ilovasini SQLAlchemy bilan bog‘lash

# Asosiy sahifa (baholar ro'yxati)
@app.route('/')
def index():
    student_id = request.args.get('student_id')
    students = Student.query.all()  # Barcha talabalarni bazadan olamiz
    
    # Agar student_id mavjud bo‘lsa, shu talabaning baholarini chiqaramiz
    if student_id:
        grades = Grade.query.filter_by(student_id=student_id).all()
    else:
        grades = Grade.query.all()
        
    return render_template('index.html', grades=grades, students=students, selected_student_id=student_id)

# Yangi baho qo‘shish
@app.route('/add_grade', methods=['POST'])
def add_grade():
    subject = request.form['subject']
    score = request.form['score']
    student_id = request.form['student_id']
   
    # Yangi baho ob'ekti yaratish
    new_grade = Grade(subject=subject, score=int(score), student_id=int(student_id))
    db.session.add(new_grade)  # Baho ma'lumotlarini bazaga saqlash
    db.session.commit()
    return redirect(url_for('index'))

# Bahoni o‘chirish
@app.route('/delete_grade/<int:id>', methods=['POST'])
def delete_grade(id):
    grade = Grade.query.get_or_404(id) # Ko‘rsatilgan id bo‘yicha bahoni topish
    db.session.delete(grade)
    db.session.commit()
    return redirect(url_for('index'))  # Asosiy sahifaga qaytish

# Baho tahrirlash formasi
@app.route('/edit_grade/<int:id>')
def edit_grade(id):
    grade = Grade.query.get_or_404(id)
    students = Student.query.all()
    return render_template('edit_grade.html', grade=grade, students=students)

# Tahrirlangan bahoni yangilash
@app.route('/update_grade/<int:id>', methods=['POST'])
def update_grade(id):
    grade = Grade.query.get_or_404(id)
    
    # Formadagi yangi ma'lumotlarni saqlash
    grade.subject = request.form['subject']
    grade.score = int(request.form['score'])
    grade.student_id = int(request.form['student_id'])  # Talabani ham o‘zgartira olamiz
    db.session.commit() # O‘zgarishlarni bazaga saqlash
    return redirect(url_for('index'))


# Flask serverini ishga tushurish
if __name__ == '__main__':
    app.run(debug=True)

