from app import app, db, Student

# Flask ilovasi kontekstida ishlash
with app.app_context():
    # Baza va jadvallarni yaratish
    db.create_all()

    # Test uchun 5 ta talaba qo‘shamiz
    student1 = Student(name="Ali Valiyev")
    student2 = Student(name="Gulnoza Karimova")
    student3 = Student(name="Salomov Anvar")
    student4 = Student(name="Niyozova Gulchehra")
    student5 = Student(name="Xasanov Sardor")

    db.session.add(student1)
    db.session.add(student2)
    db.session.add(student3)
    db.session.add(student4)
    db.session.add(student5)
    db.session.commit()

print("Baza yaratildi va 5 ta talaba qo‘shildi!")
