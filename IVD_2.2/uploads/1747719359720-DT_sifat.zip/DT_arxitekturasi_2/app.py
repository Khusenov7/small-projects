from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# SQLite database ulash
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///grades.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Model - Student va Grade
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    grades = db.relationship('Grade', backref='student', lazy=True)

class Grade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    subject = db.Column(db.String(100), nullable=False)
    score = db.Column(db.Integer, nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)

# Asosiy sahifa - baholar ro'yxati va filtrlash
@app.route('/')
def index():
    student_id = request.args.get('student_id')
    students = Student.query.all()
    if student_id:
        grades = Grade.query.filter_by(student_id=student_id).all()
    else:
        grades = Grade.query.all()
    return render_template('index.html', grades=grades, students=students, selected_student_id=student_id)

# Yangi baho qo'shish
@app.route('/add_grade', methods=['POST'])
def add_grade():
    subject = request.form['subject']
    score = request.form['score']
    student_id = request.form['student_id']

    new_grade = Grade(subject=subject, score=int(score), student_id=int(student_id))
    db.session.add(new_grade)
    db.session.commit()
    return redirect(url_for('index'))

# Bahoni o'chirish
@app.route('/delete_grade/<int:id>', methods=['POST'])
def delete_grade(id):
    grade = Grade.query.get_or_404(id)
    db.session.delete(grade)
    db.session.commit()
    return redirect(url_for('index'))

# Bahoni tahrirlash uchun formani ko'rsatish
@app.route('/edit_grade/<int:id>')
def edit_grade(id):
    grade = Grade.query.get_or_404(id)
    students = Student.query.all()
    return render_template('edit_grade.html', grade=grade, students=students)

# Bahoni yangilash
@app.route('/update_grade/<int:id>', methods=['POST'])
def update_grade(id):
    grade = Grade.query.get_or_404(id)
    grade.subject = request.form['subject']
    grade.score = int(request.form['score'])
    grade.student_id = int(request.form['student_id'])
    db.session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
